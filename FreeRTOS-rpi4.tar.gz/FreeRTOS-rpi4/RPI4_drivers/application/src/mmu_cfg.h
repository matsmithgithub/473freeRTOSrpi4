/* mmu_cfg.h */

/* # of page table configuration entries */
#define NUM_PT_CONFIGS (5)
